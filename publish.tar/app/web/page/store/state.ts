export default interface RootState {
  origin: string;
  csrf: string;
}