<template>
  <div style="font-size: 24px; text-align: center">
    Not Find The Page!!!
  </div>
</template>
<style>

</style>
<script type="text/babel">
  export default {
  }
</script>