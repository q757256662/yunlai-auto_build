<template>
  <div style="font-size: 24px; text-align: center">
    <panel-group></panel-group>
  </div>
</template>
<style>

</style>
<script type="ts">
  import PanelGroup from '../../component/panel.vue'
  export default {
    components: {
      PanelGroup
    },
  }
</script>
