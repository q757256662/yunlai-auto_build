<template>
  <div class="app-body">
      <div class="main-container">
        <router-view></router-view>
      </div>
  </div>
</template>
<style>
  @import "index.css";
</style>
<script lang="ts" src="./index.ts"></script>
