import { Vue } from 'vue-property-decorator';
export default class Content extends Vue {};