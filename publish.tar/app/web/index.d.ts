declare var EASY_ENV_IS_NODE: boolean;
type PlainObject<T = any> = { [key: string]: T };