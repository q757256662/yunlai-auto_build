"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    cors: {
        package: 'egg-cors'
    },
    webpack: {
        package: 'egg-webpack'
    },
    webpackvue: {
        package: 'egg-webpack-vue'
    }
};
