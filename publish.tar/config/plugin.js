"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    vuessr: {
        package: 'egg-view-vue-ssr'
    }
};
