
import { Application, EggAppConfig } from 'egg';

export default (appInfo: EggAppConfig) => {
  const exports: any = {};

  return exports;
};
