export default {
  cors: {
    package: 'egg-cors'
  },
  webpack: {
    package: 'egg-webpack'
  },
  webpackvue : {
    package: 'egg-webpack-vue'
  }
};