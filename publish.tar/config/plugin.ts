export default {
  vuessr: {
    package: 'egg-view-vue-ssr'
  }
};